import React, { Component } from 'react';


export default class JsFWList extends Component {
    render() {
        return (
            <div>
                Hi there!
        </div>)
    }
}